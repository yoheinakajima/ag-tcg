"""cg_typed candidate entrypoint — cg_typed_water_phase_aware_tempo_v1.

OWNED PASS-46G interpretable phase/role FAST TURN-PLANNER candidate. The hot path is
the VERBATIM ``turn_planner_profiles.py`` INLINE_SCORER_V2 region (an interpretable
linear model over coarse action families, modulated by an OBSERVABLE-only phase label
and a target-area role label) driven by the embedded Pass-46G profile. There is NO
online Search in this path. The deck is the selected internal source deck, unchanged.

Phase is a coarse observable heuristic LABEL (from own-board turn/energy/deck +
legal option families) and role is a target-area label (targets_active/targets_bench);
NEITHER is a lethal / KO / exact-damage / Boss-gust / spread / globally-best-action
claim. No opponent hidden zones are read.

No reference-agent policy code is copied; the only bundled reference asset is the
``cg`` SDK (allowed). Runtime contract: ``agent(obs_dict) -> list[int]`` of legal
option indices (or the 60 deck card ids on the deck-submission step). Never raises.

LOCAL benchmark-lane feasibility agent — NOT a Kaggle score / leaderboard / strength
claim. NO upload / submit / promote / mutate.
"""
from __future__ import annotations

import json as _json
import os as _os
import sys as _sys

# --- Bundled cg SDK import (robust to cwd; AST-visible for the cg_typed lane) ---
try:
    from cg import api as _cg
except Exception:  # pragma: no cover - resolve cg/ next to this file, then retry
    try:
        _here = _os.path.dirname(_os.path.abspath(__file__))
        if _here and _here not in _sys.path:
            _sys.path.insert(0, _here)
    except Exception:
        pass
    try:
        from cg import api as _cg
    except Exception:
        _cg = None

# --- Embedded Pass-46G interpretable phase/role profile -------------------------
# Loaded from a JSON string so the embedded profile is byte-synced with the chosen
# entry of data/experiments/pass46g_profile_catalog.json. Never raises at import.
try:
    _PROFILE = _json.loads(r'''{
  "calibrated": false,
  "deckout_draw_penalty": 0.0,
  "deckout_draw_safety": {
    "deckout_draw_penalty": 0.0,
    "drawish_families": [
      "use_ability",
      "select_card"
    ],
    "low_deck_threshold": 8,
    "note": "penalty applied to draw-ish families only when your visible deckCount is at/below the low-deck threshold (count-only signal)."
  },
  "end_pass_penalty_when_productive": -3.0,
  "no_claims": [
    "no_exact_damage",
    "no_lethal",
    "no_missed_ko",
    "no_boss_gust",
    "no_spread",
    "no_best_action",
    "phase_is_observable_label_not_strength_claim",
    "role_is_target_area_label_not_correctness_claim"
  ],
  "phase_weights": {
    "attack_ready": {
      "attach_energy": 0.2,
      "attack": 1.0,
      "play_from_hand": -0.2
    },
    "develop": {
      "attach_energy": 0.5,
      "attack": -0.2,
      "play_from_hand": 0.3,
      "use_ability": 0.4
    },
    "late_game": {
      "attack": 0.6,
      "select_card": -0.2,
      "use_ability": 0.3
    },
    "recovery": {
      "attack": -0.3,
      "move_energy": 0.4,
      "play_from_hand": 0.5,
      "play_in_play": 0.5,
      "use_ability": 0.4
    },
    "setup": {
      "attach_energy": 0.3,
      "attack": -0.4,
      "play_from_hand": 0.6,
      "play_in_play": 0.5
    }
  },
  "profile_id": "phase_aware_tempo_v1",
  "rationale": "Tempo planner: scores the SAME action family differently by observable phase (setup develops the board and avoids attacking; develop attaches/uses abilities; attack_ready commits to the attack family; recovery rebuilds the board and re-routes energy; late_game leans on attacking). Ending the turn is strongly penalised whenever a productive option remains. phase is a coarse observable label, not a strength/lethal claim.",
  "role": "candidate",
  "role_weights": {},
  "schema_version": "pass46g_turn_scorer_v1",
  "source": "hand_designed; family_seed=pass46f:search_calibrated_v0",
  "unsupported_claims": {
    "best_action": "the choice is the highest-scoring family under THIS profile, not a globally optimal action.",
    "boss_gust": "no forced-switch / gust targeting is asserted.",
    "exact_damage": "the scorer ranks action families; it computes no damage.",
    "lethal": "no KO / lethal is computed or asserted.",
    "missed_ko": "no missed-KO is computed or asserted.",
    "no_hidden_state": "no opponent hidden hand / deck contents / prize contents are read; only your own visible board and count-only signals are used.",
    "phase_is_label_not_claim": "phase is a coarse observable heuristic label (turn / own board / legal menu); it asserts no attack-readiness, advantage, or tempo claim.",
    "role_is_target_area_only": "role is read from the option's own inPlayArea (active vs bench); it asserts only which of YOUR pokemon an option targets, never that the target is correct or optimal.",
    "spread": "no spread distribution is asserted."
  },
  "weights": {
    "bias": 0.0,
    "fam_attach_energy": 1.5,
    "fam_attack": 0.975,
    "fam_effect_choice": 0.2,
    "fam_end_turn": -0.5,
    "fam_move_energy": 0.3,
    "fam_other": 0.1,
    "fam_play_from_hand": 0.4,
    "fam_play_in_play": 0.4,
    "fam_select_card": 0.3,
    "fam_use_ability": 0.6
  }
}''')
except Exception:
    _PROFILE = {"profile_id": "embedded_fallback", "weights": {}}

# OptionType END marker (mirror cg.api.OptionType; used only by the legal fallback).
OT_END = 14


# ---------------------------------------------------------------------------
# Universal accessors + generic legal-selection contract (never raise).
# ---------------------------------------------------------------------------
def _g(obj, key, default=None):
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _as_int(v, default=None):
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except (TypeError, ValueError):
        return default


def _get_select(obs):
    s = _g(obs, "select")
    return s if (isinstance(s, dict) or s is not None) else None


def _get_options(select):
    for key in ("option", "options", "choices"):
        v = _g(select, key)
        if isinstance(v, tuple):
            v = list(v)
        if isinstance(v, list):
            return v
    return []


def _min_max(select, n):
    mx = _as_int(_g(select, "maxCount"), 1 if n else 0)
    mn = _as_int(_g(select, "minCount"), 0)
    mx = 0 if mx is None or mx < 0 else min(mx, n)
    mn = 0 if mn is None or mn < 0 else mn
    if mn > mx:
        mn = mx
    return mn, mx


def _fallback_action(n, mn, mx):
    if n <= 0 or mx <= 0:
        return []
    mx = min(mx, n)
    mn = max(0, min(mn, mx))
    if mx == 1:
        return [0]
    take = mn if mn > 0 else mx
    return list(range(min(take, n)))


def _validate(result, n, mn, mx):
    if n <= 0 or mx <= 0:
        return []
    if not isinstance(result, (list, tuple)):
        result = []
    seen, out = set(), []
    for it in result:
        idx = _as_int(it)
        if idx is not None and 0 <= idx < n and idx not in seen:
            seen.add(idx)
            out.append(idx)
    if len(out) > mx:
        out = out[:mx]
    if len(out) < mn:
        for idx in range(n):
            if len(out) >= mn:
                break
            if idx not in seen:
                seen.add(idx)
                out.append(idx)
    if not out and (mn > 0 or mx >= 1):
        return _fallback_action(n, mn, mx)
    return out


# ---------------------------------------------------------------------------
# Deck-return plumbing (own deck; resilient to cwd; harness may inject _DECK_IDS).
# ---------------------------------------------------------------------------
_DECK_IDS = None
_EMBEDDED_DECK = [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 721, 721, 721, 721, 722, 722, 722, 722, 723, 723, 723, 723, 1092, 1121, 1121, 1121, 1121, 1145, 1145, 1163, 1163, 1219, 1219, 1219, 1219, 1227, 1227, 1227, 1227, 1262, 1262]


def _deck_paths():
    paths = []
    try:
        here = _os.path.dirname(_os.path.abspath(__file__))
        paths.append(_os.path.join(here, "deck.csv"))
    except Exception:
        pass
    paths.append("deck.csv")
    paths.append("/kaggle_simulations/agent/deck.csv")
    return paths


def _load_deck_ids():
    global _DECK_IDS
    if _DECK_IDS:
        return _DECK_IDS
    ids = []
    for p in _deck_paths():
        try:
            if not _os.path.exists(p):
                continue
            parsed = []
            with open(p, encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        v = _as_int(line)
                        if v is not None:
                            parsed.append(v)
            if len(parsed) == 60:
                ids = parsed
                break
            if parsed and not ids:
                ids = parsed
        except Exception:
            continue
    if len(ids) != 60:
        ids = list(_EMBEDDED_DECK)
    _DECK_IDS = ids
    return _DECK_IDS


# ===================== INLINE_SCORER_V2_BEGIN =====================
# SELF-CONTAINED: pure builtins only. No type annotations, no imports, no src
# references. Copied VERBATIM into the candidate main.py by the generator.

# Option ``type`` -> coarse action family (positively-observed cabt codes only).
# Parity-tested against ptcg_activegraph.analysis.action_resolver.OPTION_TYPE_CLASS.
OPTION_TYPE_CLASS = {
    0: "effect_choice",
    1: "effect_choice",
    2: "effect_choice",
    3: "select_card",
    6: "move_energy",
    7: "play_from_hand",
    8: "attach_energy",
    9: "use_ability",
    10: "play_in_play",
    12: "end_turn",
    13: "attack",
    14: "end_turn",
}

# Action family -> linear-model feature key.
FAMILY_FEATURE = {
    "attack": "fam_attack",
    "attach_energy": "fam_attach_energy",
    "play_from_hand": "fam_play_from_hand",
    "use_ability": "fam_use_ability",
    "play_in_play": "fam_play_in_play",
    "move_energy": "fam_move_energy",
    "select_card": "fam_select_card",
    "effect_choice": "fam_effect_choice",
    "end_turn": "fam_end_turn",
    "unknown": "fam_other",
}

FEATURE_KEYS = (
    "bias", "fam_attack", "fam_attach_energy", "fam_play_from_hand",
    "fam_use_ability", "fam_play_in_play", "fam_move_energy", "fam_select_card",
    "fam_effect_choice", "fam_end_turn", "fam_other",
)

# cg AreaType codes used for the honest role (target-area) label.
AREA_ACTIVE = 4
AREA_BENCH = 5

# Coarse phase-detection thresholds (fixed module constants so the phase LABEL is
# consistent across every profile; profiles differ only in how they WEIGHT a phase).
PHASE_LOW_DECK = 8        # your visible deckCount at/below this => late_game / low_deck
PHASE_LOW_PRIZE = 2       # your remaining prize COUNT at/below this => late_game
PHASE_RECOVERY_HP_FRAC = 0.5  # active visible hp <= 50% of its maxHp => recovery

# Families treated as draw-ish for the optional low-deck safety penalty (coarse prior:
# these families are the ones most associated with drawing / searching the deck).
DRAWISH_FAMILIES = ("use_ability", "select_card")


def _num(x):
    try:
        if isinstance(x, bool):
            return 0.0
        return float(x)
    except Exception:
        return 0.0


def _is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def family_for_option(option):
    """Coarse, honest action family for a raw cg option dict (never raises)."""
    if not isinstance(option, dict):
        return "unknown"
    return OPTION_TYPE_CLASS.get(option.get("type"), "unknown")


def option_role(option):
    """Honest target-AREA label from the option's own inPlayArea (never raises).

    ``targets_active`` (inPlayArea == active spot) / ``targets_bench`` (bench) /
    ``role_none`` (no destination area in the option schema). Asserts only WHICH of
    your pokemon the option targets, never that the target is correct.
    """
    try:
        if not isinstance(option, dict):
            return "role_none"
        a = option.get("inPlayArea")
        if a == AREA_ACTIVE:
            return "targets_active"
        if a == AREA_BENCH:
            return "targets_bench"
        return "role_none"
    except Exception:
        return "role_none"


def _raw_options(select):
    opts = None
    try:
        if isinstance(select, dict):
            opts = select.get("option")
            if not isinstance(opts, list):
                opts = select.get("options")
            if not isinstance(opts, list):
                opts = select.get("choices")
    except Exception:
        opts = None
    return opts if isinstance(opts, list) else []


def _your_player(board):
    try:
        if not isinstance(board, dict):
            return None
        players = board.get("players")
        if not isinstance(players, list) or not players:
            return None
        yi = board.get("yourIndex")
        if not isinstance(yi, int) or isinstance(yi, bool) or yi < 0 or yi >= len(players):
            yi = 0
        p = players[yi]
        return p if isinstance(p, dict) else None
    except Exception:
        return None


def _attack_available(select):
    try:
        for o in _raw_options(select):
            if family_for_option(o) == "attack":
                return True
        return False
    except Exception:
        return False


def _has_productive_alternative(select):
    try:
        for o in _raw_options(select):
            if family_for_option(o) != "end_turn":
                return True
        return False
    except Exception:
        return False


def detect_phase(select, board):
    """Coarse, honest phase LABEL from your OWN observable board + legal menu.

    Precedence: late_game (low deck / few prizes left) > attack_ready (an attack option
    is legal now) > recovery (your active visibly at <=50% hp) > setup (no active, or
    very first turn) > develop. Never raises (returns ``develop`` on any failure). Uses
    only your own visible board and COUNT-only prize/deck signals; no hidden state.
    """
    try:
        you = _your_player(board)
        deck = you.get("deckCount") if isinstance(you, dict) else None
        prize_remaining = None
        has_active = False
        active_hp = None
        active_max = None
        if isinstance(you, dict):
            pr = you.get("prize")
            if isinstance(pr, list):
                prize_remaining = len(pr)
            act = you.get("active")
            if isinstance(act, list) and act and isinstance(act[0], dict):
                has_active = True
                active_hp = act[0].get("hp")
                active_max = act[0].get("maxHp")
        turn = board.get("turn") if isinstance(board, dict) else None
        if _is_num(deck) and deck <= PHASE_LOW_DECK:
            return "late_game"
        if _is_num(prize_remaining) and prize_remaining <= PHASE_LOW_PRIZE:
            return "late_game"
        if _attack_available(select):
            return "attack_ready"
        if has_active and _is_num(active_hp) and _is_num(active_max) \
                and active_max > 0 and active_hp <= PHASE_RECOVERY_HP_FRAC * active_max:
            return "recovery"
        if not has_active:
            return "setup"
        if _is_num(turn) and turn <= 1:
            return "setup"
        return "develop"
    except Exception:
        return "develop"


def extract_features(option, select=None, board=None):
    """Interpretable feature dict for one option (never raises).

    Carries: ``bias``, the family one-hot feature key, plus the observable context
    signals ``family`` / ``phase`` / ``role`` / ``low_deck`` / ``productive_alternatives``
    used by the additive scorer. ``select`` / ``board`` are the live select menu and
    your own ``current`` board.
    """
    feats = {"bias": 1.0}
    try:
        fam = family_for_option(option)
    except Exception:
        fam = "unknown"
    feats["family"] = fam
    feats[FAMILY_FEATURE.get(fam, "fam_other")] = 1.0
    try:
        feats["role"] = option_role(option)
    except Exception:
        feats["role"] = "role_none"
    try:
        feats["phase"] = detect_phase(select, board)
    except Exception:
        feats["phase"] = "develop"
    low = 0.0
    try:
        you = _your_player(board)
        deck = you.get("deckCount") if isinstance(you, dict) else None
        if _is_num(deck) and deck <= PHASE_LOW_DECK:
            low = 1.0
    except Exception:
        low = 0.0
    feats["low_deck"] = low
    try:
        feats["productive_alternatives"] = (
            1.0 if _has_productive_alternative(select) else 0.0)
    except Exception:
        feats["productive_alternatives"] = 0.0
    return feats


def score_option(features, profile):
    """Transparent additive linear score for one option (never raises).

    score = bias + family_weight + phase_adj[phase][family] + role_adj[role]
            + end_pass_penalty (when ending with productive options remaining)
            + deckout_draw_penalty (when deck is low and the family is draw-ish).
    With empty phase/role tables and zero penalties this reduces to the family-only
    baseline ordering.
    """
    try:
        if not isinstance(features, dict):
            return 0.0
        weights = {}
        phase_weights = {}
        role_weights = {}
        epp = 0.0
        ddp = 0.0
        if isinstance(profile, dict):
            w = profile.get("weights")
            if isinstance(w, dict):
                weights = w
            pw = profile.get("phase_weights")
            if isinstance(pw, dict):
                phase_weights = pw
            rw = profile.get("role_weights")
            if isinstance(rw, dict):
                role_weights = rw
            epp = _num(profile.get("end_pass_penalty_when_productive", 0.0))
            ddp = _num(profile.get("deckout_draw_penalty", 0.0))
        fam = features.get("family", "unknown")
        fam_key = FAMILY_FEATURE.get(fam, "fam_other")
        total = 0.0
        total += _num(weights.get("bias", 0.0)) * _num(features.get("bias", 0.0))
        total += _num(weights.get(fam_key, 0.0))
        phase = features.get("phase")
        pdict = phase_weights.get(phase) if isinstance(phase_weights, dict) else None
        if isinstance(pdict, dict):
            total += _num(pdict.get(fam, 0.0))
        role = features.get("role")
        if role in role_weights:
            total += _num(role_weights.get(role, 0.0))
        if fam == "end_turn" and _num(features.get("productive_alternatives", 0.0)) > 0.0:
            total += epp
        if _num(features.get("low_deck", 0.0)) > 0.0 and fam in DRAWISH_FAMILIES:
            total += ddp
        return total
    except Exception:
        return 0.0


def _select_counts(select):
    """Return (options_list, n_options, min_count, max_count) (never raises)."""
    opts = _raw_options(select)
    n = len(opts)
    mn = select.get("minCount") if isinstance(select, dict) else None
    mx = select.get("maxCount") if isinstance(select, dict) else None
    try:
        mn = int(mn)
    except Exception:
        mn = 1
    try:
        mx = int(mx)
    except Exception:
        mx = mn
    if mn < 0:
        mn = 0
    if mx < mn:
        mx = mn
    return opts, n, mn, mx


def score_options(select, board, profile):
    """Return a list of (index, score, family) for every option (never raises)."""
    out = []
    try:
        opts, n, _mn, _mx = _select_counts(select)
        for i in range(n):
            o = opts[i]
            try:
                fam = family_for_option(o)
                sc = score_option(extract_features(o, select, board), profile)
            except Exception:
                fam, sc = "unknown", 0.0
            out.append((i, sc, fam))
    except Exception:
        return out
    return out


def choose_indices(select, board, profile):
    """Pick a LEGAL select-index list maximising the profile score (never raises).

    Picks the minimum required count (at least one when selection is allowed) of the
    highest-scoring distinct options, tie-broken by lowest index. Returns ``[]`` only
    when no selection is possible; the caller supplies its own legal fallback.
    """
    try:
        opts, n, mn, mx = _select_counts(select)
        if n == 0:
            return []
        scored = []
        for i in range(n):
            try:
                sc = score_option(extract_features(opts[i], select, board), profile)
            except Exception:
                sc = 0.0
            scored.append((sc, -i, i))
        scored.sort(reverse=True)
        k = mn if mn >= 1 else 1
        if k > mx:
            k = mx
        if k > n:
            k = n
        if k <= 0:
            return []
        chosen = sorted(t[2] for t in scored[:k])
        return chosen
    except Exception:
        return []
# ===================== INLINE_SCORER_V2_END =====================


# ---------------------------------------------------------------------------
# Entrypoint — fast phase/role turn-planner over raw options (no online Search).
# ---------------------------------------------------------------------------
def agent(obs_dict):
    """Kaggle/cg entrypoint. Always returns list[int] of legal indices."""
    # 0. Deck-submission step (select present but null) -> return 60 card ids.
    try:
        if isinstance(obs_dict, dict) and "select" in obs_dict \
                and obs_dict["select"] is None:
            deck = _load_deck_ids()
            if len(deck) == 60:
                return deck
    except Exception:
        pass

    select = _get_select(obs_dict)
    options = _get_options(select)
    n = len(options)
    mn, mx = _min_max(select, n)
    if n == 0 or mx <= 0:
        return []

    # 1. Fast phase/role scorer over the raw options (inlined, never-raise).
    try:
        board = obs_dict.get("current") if isinstance(obs_dict, dict) else None
        decision = choose_indices(select, board, _PROFILE)
    except Exception:
        decision = None
    if decision:
        out = _validate(decision, n, mn, mx)
        if out:
            return out

    # 2. Generic legal fallback: prefer an action over ending the turn.
    try:
        if mx == 1:
            for i, o in enumerate(options):
                if _as_int(_g(o, "type")) != OT_END:
                    return [i]
            return [0]
    except Exception:
        pass
    return _validate(_fallback_action(n, mn, mx), n, mn, mx)


if __name__ == "__main__":
    demo = {"logs": [], "current": None,
            "select": {"option": [{"type": 13}, {"type": 8}, {"type": 14}],
                       "maxCount": 1, "minCount": 0}}
    print("demo:", agent(demo))
